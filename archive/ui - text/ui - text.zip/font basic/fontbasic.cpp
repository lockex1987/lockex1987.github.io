#include <windows.h>
#include <math.h>
#include <stdio.h>

#include <stdarg.h>
#include <GL/glaux.h>		// Header File For The Glaux Library
#include <GL/glut.h>

GLuint base;
HDC hDC = NULL;

GLfloat	cnt1;				// 1st Counter Used To Move Text & For Coloring
GLfloat	cnt2;				// 2nd Counter Used To Move Text & For Coloring

GLvoid buildFont() {
	HFONT	font;
	HFONT	oldfont;
	base = glGenLists(96);
	font = CreateFont(	-24,
						0,	
						0,	
						0,	
						FW_BOLD,
						FALSE,	
						FALSE,	
						FALSE,	
						ANSI_CHARSET,
						OUT_TT_PRECIS,
						CLIP_DEFAULT_PRECIS,
						ANTIALIASED_QUALITY,
						FF_DONTCARE|DEFAULT_PITCH,
						"Courier New");

	oldfont = (HFONT)SelectObject(hDC, font);
	wglUseFontBitmaps(hDC, 32, 96, base);	
	SelectObject(hDC, oldfont);
	DeleteObject(font);
}


GLvoid glPrint(const char *fmt) {
	char text[256];

	va_list	ap;
	va_start(ap, fmt);
	vsprintf(text, fmt, ap);
	va_end(ap);

	glPushAttrib(GL_LIST_BIT);
	glListBase(base - 32);
	glCallLists(strlen(text), GL_UNSIGNED_BYTE, text);
	glPopAttrib();
}

void init() {
	glClearColor(0, 0, 0, 1);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);

	buildFont();
}

float angle = 0;

void display() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	//gluLookAt(5, 5, 5, 0, 0, 0, 0, 1, 0);
	glRotatef(angle, 0, 1, 0);
	glutWireSphere(1, 12, 12);

	glTranslatef(0.0f,0.0f,-1.0f);						// Move One Unit Into The Screen
	// Pulsing Colors Based On Text Position
	glColor3f(1.0f*float(cos(cnt1)),1.0f*float(sin(cnt2)),1.0f-0.5f*float(cos(cnt1+cnt2)));
	// Position The Text On The Screen
	glRasterPos2f(-0.45f+0.05f*float(cos(cnt1)), 0.32f*float(sin(cnt2)));
 	glPrint("Active OpenGL Text With NeHe - %7.2f");	// Print GL Text To The Screen
	cnt1+=0.051f;										// Increase The First Counter
	cnt2+=0.005f;										// Increase The First Counter

	glFlush();
	glutSwapBuffers();
}

void reshape(int w, int h) {
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(30, 1, 1, 50);
	glMatrixMode(GL_MODELVIEW);
}

void timer(int nothing) {
	// Thay doi thong so.
	angle++;
	glutPostRedisplay();
	
	// Ve lai.
	glutTimerFunc(20, timer, 0);
}

void keyboard(unsigned char key, int x, int y) {
	switch(key) {
	case 'a':
		break;
	case 'b':
		break;
	default:
		break;	
	}
}

void main() {
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(640, 480);
	glutInitWindowPosition(100, 150);
	glutCreateWindow("A template Glut program");
	init();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutTimerFunc(0, timer, 0);
	glutKeyboardFunc(keyboard);
	glutMainLoop();
}

