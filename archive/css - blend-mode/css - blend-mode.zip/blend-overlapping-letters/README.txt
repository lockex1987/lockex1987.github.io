A Pen created at CodePen.io. You can find this one at http://codepen.io/cjgammon/pen/nEzpj.

 CSS Blend Mode Example 

Note: Requires Chrome Canary & Experimental Web Platform Features enabled. 

Fork of found art & pen from Chris Coyier

saw at airport:

![img](http://f.cl.ly/items/0S2z0D1z0f2e450w0l06/photo.JPG)