A Pen created at CodePen.io. You can find this one at http://codepen.io/hxd/pen/aLpbh.

 A text filling with water animation, for preloaders and such.