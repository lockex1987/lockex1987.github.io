function initPubTailorConfig(){


}

