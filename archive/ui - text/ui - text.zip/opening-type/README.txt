A Pen created at CodePen.io. You can find this one at http://codepen.io/bernardo/pen/ugApF.

 Just hover on letters 

inspired by Edenspiekermann work for Kröller-Müller Museum - http://edenspiekermann.com/projects/kroller-muller-museum