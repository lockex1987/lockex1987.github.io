A Pen created at CodePen.io. You can find this one at http://codepen.io/nw/pen/jhKtk.

 Needed to make a placeholder logo, so had a play with text-shadows and perspective to give it a 3D effect.