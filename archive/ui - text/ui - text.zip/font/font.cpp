#include <math.h>
#include <gl\glut.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include <string.h>
#include <stdlib.h>

float angle = 0.0, deltaAngle = 0.0;
float x = 0.0f, y = 1.75f, z = 5.0f;  // tao do dung
float lx = 0.0f, ly = 0.0f, lz = -1.0f;  // huong nhin
int deltaMove = 0;
int font = (int)GLUT_BITMAP_8_BY_13;

// Xu ly su kien khi thay doi kich thuoc man hinh.
void changeSize(int w, int h) {
	// Prevent a divide by zero, when window is too short
	// (you cant make a window of zero width).
	if(h == 0)
		h = 1;
	float ratio = 1.0f*w/h;
	// Reset the coordinate system before modifying
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// Set the viewport to be the entire window
	glViewport(0, 0, w, h);
	// Set the clipping volume
	gluPerspective(45, ratio, 0.1, 100);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(x, y, z, x+lx, y+ly, z+lz, 0.0f, 1.0f, 0.0f);
}

// Ham khoi tao.
void initScene() {
	glEnable(GL_DEPTH_TEST);
}

// Xoay huong nhin.
void orientMe(float ang) {
	lx = sin(ang);
	lz = -cos(ang);
	glLoadIdentity();
	gluLookAt(x, y, z, x+lx, y+ly, z+lz, 0.0f, 1.0f, 0.0f);
}

// Di chuyen.
void moveMeFlat(int i) {
	x = x+i*(lx)*0.01;
	z = z+i*(lz)*0.01;
	glLoadIdentity();
	gluLookAt(x, y, z, x+lx, y+ly, z+lz, 0.0f, 1.0f, 0.0f);
}

// Ve xau <string> tai toa do <x, y, z>, font chu la <font>.
void renderBitmapCharacher(float x, float y, float z, void *font,char *string) {
	/*
	char *c;
	glRasterPos3f(x, y, z);
	for(c = string; *c != '\0'; c++) {
		glutBitmapCharacter(font, *c);
	}
	*/

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0,640,0,480,-1,1);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	glTranslated(x,y,z);
	char *c;
	glRasterPos3f(x, y, z);
	for(c = string; *c != '\0'; c++) {
		glutBitmapCharacter(font, *c);
	}
	
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
}

// Ve hinh.
void renderScene(void) {
	if(deltaMove)
		moveMeFlat(deltaMove);
	if(deltaAngle) {
		angle += deltaAngle;
		orientMe(angle);
	}
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glPushMatrix();
	renderBitmapCharacher(200, 30, 0, (void *)font, "Dien dan tin hoc");
	//renderBitmapCharacher(3, 3.7, 0, (void *)font, "RedSun");
	glPopMatrix();
	glutSwapBuffers();
}

// Xu ly su kien ban phim.
void pressKey(int key, int x, int y) {
	switch (key) {
	case GLUT_KEY_LEFT:
		deltaAngle = -0.01f;
		break;
	case GLUT_KEY_RIGHT:
		deltaAngle = 0.01f;
		break;
	case GLUT_KEY_UP:
		deltaMove = 1;
		break;
	case GLUT_KEY_DOWN:
		deltaMove = -1;
		break;
	}
}

// Xu ly su kien ban phim.
void releaseKey(int key, int x, int y) {
	switch (key) {
	case GLUT_KEY_LEFT:
	case GLUT_KEY_RIGHT:
		deltaAngle = 0.0f;
		break;
	case GLUT_KEY_UP:
	case GLUT_KEY_DOWN:
		deltaMove = 0;
		break;
	}
}

// Xu ly su kien khi nhan menu.
void processMenuEvents(int option) {
	font = option;
}

// Tao menu, khi nhan chuot phai.
void createMenus() {
	int menu = glutCreateMenu(processMenuEvents);
	glutAddMenuEntry("8 by 13", (int)GLUT_BITMAP_8_BY_13);
	glutAddMenuEntry("9 by 15", (int)GLUT_BITMAP_9_BY_15);
	glutAddMenuEntry("Times Roman 10", (int)GLUT_BITMAP_TIMES_ROMAN_10);
	glutAddMenuEntry("Times Roman 24", (int)GLUT_BITMAP_TIMES_ROMAN_24);
	glutAddMenuEntry("Helvetica 10", (int)GLUT_BITMAP_HELVETICA_10);
	glutAddMenuEntry("Helvetica 12", (int)GLUT_BITMAP_HELVETICA_12);
	glutAddMenuEntry("Helvetica 18", (int)GLUT_BITMAP_HELVETICA_18);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}

// Xu ly su kien ban phim binh thuong.
void processNormalKeys(unsigned char key, int x, int y) {
	if(key == 27)
		exit(0);
}

int main(int argc, char **argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100,100);
	glutInitWindowSize(640,360);
	glutCreateWindow("GV");
	initScene();
	glutKeyboardFunc(processNormalKeys);
	glutIgnoreKeyRepeat(1);
	glutSpecialFunc(pressKey);
	glutSpecialUpFunc(releaseKey);
	createMenus();
	glutDisplayFunc(renderScene);
	glutIdleFunc(renderScene);
	glutReshapeFunc(changeSize);
	glutMainLoop();
	return(0);
}