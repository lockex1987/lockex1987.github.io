//Today we will make knockout style text, in just CSS

//Warning: It will only work in webkit browswers (like chrome or safari)

//All of the credit for this technique goes to the unremebered person who I somehow got the code from here: http://jsfiddle.net/m3mkx/1/