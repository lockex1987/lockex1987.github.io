A Pen created at CodePen.io. You can find this one at http://codepen.io/chriscoyier/pen/mvbpJ.

 saw at airport:

![img](http://f.cl.ly/items/0S2z0D1z0f2e450w0l06/photo.JPG)

it would be sweet to do with CSS blend modes so you could multiply the colors together, but I don't think it's going to happen: http://codepen.io/chriscoyier/pen/uBcKh blending only works on multiple backgrounds not arbitrary elements. Maybe could do with SVG though.

**Update!** works with `mix-blend-mode` (in Chrome Canary with experimental web platform features turned on) :: http://codepen.io/cjgammon/pen/nEzpj