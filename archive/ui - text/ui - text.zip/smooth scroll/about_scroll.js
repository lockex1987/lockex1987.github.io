/*fm*/





about_scroll=function(){
	
	var fr=document.createElement("iframe");
		fr.scrolling="no";

		fr.frameBorder=0;
		fr.style.height=30;
	fr.toshow='put your text here';
	fr.bgcolor='white';
	fr.scrollvari=1;
	fr.scrolltimer=10;
	fr.scrollspace=5;
	fr.scrollw=0;
	fr.scrolldw=0;
	fr.fontFace='Arial';
	fr.fontSize=9;
	fr.scrollDir=1;
		
	function frameinit(){
		var id=Math.random();
		var iddiv="A"+Math.random();
		fr.setAttribute("id",id);
		frdoc=fr.contentWindow.document;
		frdoc.body.style.margin=0;
		frdoc.body.style.background=fr.bgcolor;
		frdoc.body.style.fontFamily=fr.fontFace;
		frdoc.body.style.fontSize=fr.fontSize;
		var r=frdoc.createElement("div");
		r.setAttribute("id",iddiv);
		r.innerHTML=fr.toshow;
		frdoc.body.appendChild(r);
		if(frdoc.body.clientWidth)
		fr.scrollw=frdoc.body.clientWidth;
		var blank="<img src='space.gif' width="+fr.scrollw+" height=1>";
		//var scrollv=frdoc.getElementById(iddiv).firstChild.nodeValue;
		var scrollv=frdoc.getElementById(iddiv).innerHTML;
		frdoc.getElementById(iddiv).innerHTML="<nobr>"+blank+scrollv+blank+"</nobr>";
		if(fr.contentWindow.parent.frames[0].scrollMaxX){
			fr.scrolldw=fr.contentWindow.document.body.scrollWidth;}
		else {
			fr.scrolldw=frdoc.getElementById(iddiv).offsetWidth;}
			fr.scrolldw=fr.scrolldw-(fr.scrollw);
		}
	setTimeout(frameinit,1000);
	//var k=fr.contentWindow;
	function hscroll_L(){
		//var k=fr.contentWindow;
		fr.scrollvari=fr.scrollvari+fr.scrollspace;
		if(fr.scrollvari>=fr.scrolldw)fr.scrollvari=1;
		fr.contentWindow.scrollTo(fr.scrollvari,1);
		setTimeout(hscroll_L,fr.scrolltimer);
		};//setTimeout(hscroll_L,1000);


	function hscroll_R(){
		//var k=fr.contentWindow;
		fr.scrollvari=fr.scrollvari-fr.scrollspace;
		if(fr.scrollvari<=1)fr.scrollvari=fr.scrolldw;
		fr.contentWindow.scrollTo(fr.scrollvari,1);
		setTimeout(hscroll_R,fr.scrolltimer);
		};//setTimeout(hscroll_R,fr.scrolltimer);

	function start(){
		if(fr.scrollDir==1){
			hscroll_L();	return;		}
		if(fr.scrollDir==2){
			hscroll_R();	return;		}
		}

		setTimeout(start,1000);

	this.setMode=function(x){
		fr.scrollDir=x;
		}
	this.setSpeed_Timer=function(x,y){
		fr.scrollspace=x;
		fr.scrolltimer=y;
	}

	this.setText=function(x){
		fr.toshow=x;
		}
	this.setToDiv=function(x){
		x.appendChild(fr);
		};
	this.setBgColor=function(x){
		fr.bgcolor=x;		}
	this.setWidth=function(x){
		fr.style.width=x;

		}
	this.setHeight=function(x){
		fr.style.height=x;

		}

}
