A Pen created at CodePen.io. You can find this one at http://codepen.io/chriscoyier/pen/Kkliq.

 ctx.globalCompositeOperation not suported by all browsers, test it on firefox