A Pen created at CodePen.io. You can find this one at http://codepen.io/crismanNoble/pen/bGzqu.

 I created a simple class which will allow for knockout text effect. It looks best with pictures of space. Don't forget to tweak the background positioning.