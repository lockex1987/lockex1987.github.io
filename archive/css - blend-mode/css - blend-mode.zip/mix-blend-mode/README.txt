A Pen created at CodePen.io. You can find this one at http://codepen.io/css-tricks/pen/ZYdjmZ.

 Iterating over all the values of the `mix-blend-mode` property to help understand how they work in practice.