#include <stdio.h>
#include <windows.h>
#include <ctype.h>

int main() {
	char s[] = "nguyen ngoc linh";
	system("color 3A");
	printf("\n\n\n");
	int i, index = 0;
	while (true) {
		printf("\r     ");
		for (i = 0; i < index; i++) {
			printf("%c", s[i]);
		}
		printf("%c", toupper(s[i]));
		for (i = index + 1; i < strlen(s); i++) {
		 	printf("%c", s[i]);
		}
		Sleep(100);
		index = (index == strlen(s) - 1) ? 0 : (index + 1);
	}
}